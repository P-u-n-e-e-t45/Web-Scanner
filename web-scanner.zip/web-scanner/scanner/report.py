import csv
import io
import json

ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2, "INFO": 3}


def _sorted(findings):
    return sorted(findings, key=lambda f: ORDER.get(f["severity"], 9))


def to_text(results):
    lines = []
    for res in results:
        lines.append(f"\n== {res['url']} ==")
        if res.get("error"):
            lines.append(f"  ERROR: {res['error']}")
            continue
        if not res["findings"]:
            lines.append("  No findings.")
        for f in _sorted(res["findings"]):
            lines.append(f"  [{f['severity']}] ({f['check']}) {f['message']}")
    return "\n".join(lines)


def to_json(results):
    return json.dumps(results, indent=2)


def to_csv(results):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["url", "severity", "check", "message"])
    for res in results:
        for f in _sorted(res.get("findings", [])):
            w.writerow([res["url"], f["severity"], f["check"], f["message"]])
    return buf.getvalue()


FORMATS = {"text": to_text, "json": to_json, "csv": to_csv}
