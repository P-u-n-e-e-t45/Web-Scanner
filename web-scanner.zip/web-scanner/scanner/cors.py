from urllib.parse import urlparse

import requests


def _probe(url, origin, timeout):
    r = requests.get(url, headers={"Origin": origin}, timeout=timeout)
    return (r.headers.get("Access-Control-Allow-Origin"),
            r.headers.get("Access-Control-Allow-Credentials", "").lower() == "true")


def check_cors(url, timeout=10):
    """Probe a URL with crafted Origin headers and report CORS issues."""
    host = urlparse(url).hostname or ""
    probes = {
        "arbitrary origin": "https://evil.example",
        "null origin": "null",
        "look-alike domain": f"https://{host}.evil.example",
    }
    findings = []
    for label, origin in probes.items():
        acao, creds = _probe(url, origin, timeout)
        if acao == origin:
            severity = "HIGH" if creds else "MEDIUM"
            findings.append({
                "severity": severity, "check": "cors",
                "message": f"Reflects {label} ({origin}); credentials allowed: {creds}",
            })
        elif acao == "*":
            findings.append({"severity": "LOW", "check": "cors",
                             "message": "Wildcard Access-Control-Allow-Origin"})
            break
    return findings
