import re

REQUIRED = {
    "Strict-Transport-Security": ("MEDIUM", "Missing HSTS"),
    "Content-Security-Policy": ("MEDIUM", "Missing CSP"),
    "X-Content-Type-Options": ("LOW", "Missing X-Content-Type-Options"),
    "X-Frame-Options": ("LOW", "Missing clickjacking protection (X-Frame-Options or CSP frame-ancestors)"),
    "Referrer-Policy": ("LOW", "Missing Referrer-Policy"),
    "Permissions-Policy": ("INFO", "Missing Permissions-Policy"),
}


def check_headers(headers):
    """Return a list of finding dicts for the given response headers."""
    findings = []
    h = {k.lower(): v for k, v in headers.items()}

    for name, (severity, message) in REQUIRED.items():
        if name.lower() not in h:
            if name == "X-Frame-Options" and "frame-ancestors" in h.get("content-security-policy", ""):
                continue
            findings.append({"severity": severity, "check": "header", "message": message})

    hsts = h.get("strict-transport-security")
    if hsts:
        m = re.search(r"max-age=(\d+)", hsts, re.I)
        if not m or int(m.group(1)) < 15552000:
            findings.append({"severity": "LOW", "check": "header",
                             "message": "HSTS max-age is below 180 days"})

    csp = h.get("content-security-policy")
    if csp:
        for bad in ("unsafe-inline", "unsafe-eval"):
            if bad in csp:
                findings.append({"severity": "MEDIUM", "check": "header",
                                 "message": f"CSP allows '{bad}'"})

    xcto = h.get("x-content-type-options")
    if xcto and xcto.strip().lower() != "nosniff":
        findings.append({"severity": "LOW", "check": "header",
                         "message": "X-Content-Type-Options should be 'nosniff'"})
    return findings
