import argparse
import sys

import requests

from .cors import check_cors
from .headers import check_headers
from .report import FORMATS


def scan(url, timeout=10):
    try:
        r = requests.get(url, timeout=timeout)
        findings = check_headers(r.headers) + check_cors(url, timeout)
        return {"url": url, "status": r.status_code, "findings": findings}
    except requests.RequestException as exc:
        return {"url": url, "error": str(exc), "findings": []}


def main(argv=None):
    p = argparse.ArgumentParser(prog="scanner", description="Security header and CORS scanner")
    p.add_argument("urls", nargs="*", help="Target URLs")
    p.add_argument("-f", "--file", help="File with one URL per line")
    p.add_argument("--format", choices=FORMATS, default="text")
    p.add_argument("-o", "--output", help="Write report to this file")
    p.add_argument("--timeout", type=int, default=10)
    p.add_argument("--authorized", action="store_true",
                   help="Confirm you own the targets or have written permission to test them")
    args = p.parse_args(argv)

    if not args.authorized:
        p.error("--authorized is required: only scan sites you own or have permission to test")

    urls = list(args.urls)
    if args.file:
        with open(args.file) as fh:
            urls += [line.strip() for line in fh if line.strip()]
    if not urls:
        p.error("provide at least one URL or --file")

    results = [scan(u, args.timeout) for u in urls]
    report = FORMATS[args.format](results)

    if args.output:
        with open(args.output, "w") as fh:
            fh.write(report)
    else:
        print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
