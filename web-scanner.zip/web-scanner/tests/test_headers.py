from scanner.headers import check_headers


def msgs(headers):
    return [f["message"] for f in check_headers(headers)]


def test_missing_all():
    assert "Missing HSTS" in msgs({})


def test_weak_hsts():
    m = msgs({"Strict-Transport-Security": "max-age=100"})
    assert "HSTS max-age is below 180 days" in m


def test_csp_unsafe_inline():
    m = msgs({"Content-Security-Policy": "script-src 'unsafe-inline'"})
    assert "CSP allows 'unsafe-inline'" in m


def test_frame_ancestors_satisfies_xfo():
    m = msgs({"Content-Security-Policy": "frame-ancestors 'none'"})
    assert not any("clickjacking" in x for x in m)
